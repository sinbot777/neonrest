# Contributor License Agreement (CLA)

By contributing to Neonrest, you agree to the following:

1. You wrote the code yourself, or have the right to submit it.
2. You grant Brenden Kelly the right to use, modify, license, and distribute your contribution as part of Neonrest.
3. You understand that your contribution may be used in a commercial project.
4. You do not expect compensation, credit, or rights beyond those granted in this agreement.
5. You agree not to submit code copied from sources with restrictive licenses (e.g. GPL) unless it is clearly marked and permitted.

Signed: [Your GitHub username or real name]
