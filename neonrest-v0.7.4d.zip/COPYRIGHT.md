# Copyright Notice

All source code in this repository is authored by Brenden Kelly using AI assistance from ChatGPT.
No third-party source code is included unless otherwise noted.

This project is maintained under the terms specified in the LICENSE file.
